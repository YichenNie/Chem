import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


C = ['Toluene', 'Aniline', 'BenzoicAcid', 'BenzoicAcidTotal']


for i in range(len(C)):
    vars()[C[i]] = [[] for j in range(4)]


with open('statistic.txt', 'r') as st:
    lns = st.readlines()
    for ln in lns:
        ln = eval('[' + ln + ']')
        for i in range(len(C)):
            eval(C[i])[ln[0]-1].append(ln[i+1])

with open('output.txt', 'w') as op:
    for i in C:

        print(i)
        op.write(i + '\n')
        df = pd.DataFrame(list(zip(*eval(i))), columns=['1', '2', '3', '4'],
                        )
        boxplot = df.boxplot(showmeans=True, showfliers=True, showcaps=True, 
                            showbox=True, return_type='both')
        
        for parameters in ['caps', 'boxes', 'medians', 'fliers', 'means']:
            op.write('  ' + parameters + '\n')
            for j in boxplot[1][parameters]:
                op.write('      ' + str(j.get_ydata()) + '\n')

        plt.xlabel('Route')
        plt.ylabel('m (g)')
        plt.title(i)
        plt.rcParams['savefig.dpi'] = 500
        plt.savefig(i + '.png')
        plt.close()


print('END')