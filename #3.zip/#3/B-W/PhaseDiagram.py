import matplotlib.pyplot as plt
import numpy as np
import math
from scipy import optimize


with open('PhaseDiagram.txt', 'r') as d:
    data = d.readlines()
    for i in range(len(data)):
        ln = eval('[' + data[i] + ']')
        plt.scatter(ln[0], ln[1], s=5, c=(0.8, 0.3, 0.3))
'''    for i in range(41):
        plt.scatter(4.57+(100-4.57)/40*i, 94.6, s=5, c=(0.3, 0.5, 0.8))
        # w=4.57, 73.5, t=94.6'''


plt.title('Benzoic acid/Water system')
plt.xlim(xmax = 100, xmin = 0)
plt.ylim(ymax = 130, ymin = 20)
plt.rcParams['savefig.dpi'] = 1000
plt.rcParams['figure.dpi'] = 1000
plt.xlabel('w(benzoic acid) (%)')
plt.ylabel('t (°C)')
plt.savefig('PhaseDiagram.png')
plt.show()