import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize


with open('RefractiveIndex.txt', 'r') as d:
    data = d.readlines()
    '''for i in range(len(data)):
        ln = eval('[' + data[i] + ']')
        plt.scatter(ln[0], ln[1], s=5, c=(0.8, 0.5, 0.2))'''
    v = []
    t = []
    for i in range(len(data)):
        ln = eval('[' + data[i] + ']')
        v.append(ln[0])
        t.append(ln[1])
        plt.scatter(ln[0], ln[1], s=5, c=(0.8, 0.3, 0.3))
    x = np.array(v)
    y = np.array(t)
    curve = np.poly1d(np.polyfit(x, y, 2))
    print(curve)
    xx = np.linspace(0, 100, 100)
    yy = curve(xx)
    plt.plot(xx, yy, c=(0.8, 0.3, 0.3), linestyle='solid')



plt.title('Anline/Toluene system')
plt.xlim(xmax = 100, xmin = 0)
plt.ylim(ymax = 1.5700, ymin = 1.4950)
plt.rcParams['savefig.dpi'] = 1000
plt.rcParams['figure.dpi'] = 1000
plt.xlabel('w(aniline)/%')
plt.ylabel('n')
plt.savefig('PhaseDiagram.png')
plt.show()