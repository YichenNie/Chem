import matplotlib.pyplot as plt
import numpy as np
import math
from scipy import optimize


with open('PhaseDiagram.txt', 'r') as d:
    data = d.readlines()
    for i in range(len(data)):
        ln = eval('[' + data[i] + ']')
        plt.scatter(ln[0], ln[1], s=5, c=(ln[2]**2, 0.5, 0.2))


plt.title('Anline/Toluene system')
plt.xlim(xmax = 1, xmin = 0)
plt.ylim(ymax = 185, ymin = 110)
plt.rcParams['savefig.dpi'] = 1000
plt.rcParams['figure.dpi'] = 1000
plt.xlabel('x(toluene)')
plt.ylabel('t (°C)')
plt.savefig('PhaseDiagram.png')
plt.show()